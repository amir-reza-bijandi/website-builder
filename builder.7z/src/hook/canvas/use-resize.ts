import useCanvasStore from '@/store/canvas-store';
import type { AbsoluteRect, Direction, Position } from '@/type/general-types';
import getElementById from '@/utility/canvas/get-element-by-id';
import { useRef } from 'react';
import { useShallow } from 'zustand/react/shallow';

export default function useResize(elementIdList: string[]) {
  const {
    updateElement,
    isResizing,
    setResizing,
    zoomFactor,
    isSelectionVisible,
    setSelectionVisible,
  } = useCanvasStore(
    useShallow((store) => ({
      zoomFactor: store.view.zoomFactor,
      updateElement: store.updateElement,
      setResizing: store.setResizing,
      isResizing: store.isResizing,
      isSelectionVisible: store.isSelectionVisible,
      setSelectionVisible: store.setSelectionVisible,
    })),
  );

  const initialMousePositionRef = useRef<Position>();
  const initialElementRectListRef = useRef<(AbsoluteRect & { id: string })[]>();
  const resizeDirectionRef = useRef<Direction>();

  const canvas = document.getElementById('canvas')!;
  const elementList = elementIdList.map(
    (elementId) => getElementById(elementId)!,
  );

  const handleResizing = ({ clientX, clientY, currentTarget }: MouseEvent) => {
    if (!isResizing) {
      setResizing(true);
    }
    const { x: initialClientX, y: initialClientY } =
      initialMousePositionRef.current!;

    const deltaClientX = (clientX - initialClientX) / zoomFactor;
    const deltaClientY = (clientY - initialClientY) / zoomFactor;

    const canvasWidth = parseInt(getComputedStyle(canvas).width);
    const canvasHeight = parseInt(getComputedStyle(canvas).height);

    const initialSelectionRect = getSelectionRect(
      initialElementRectListRef.current!,
    );

    let resizedElementRectList: (AbsoluteRect & { id: string })[] =
      initialElementRectListRef.current!.map(
        (
          {
            id,
            left: initialLeft,
            right: initialRight,
            top: initialTop,
            bottom: initialBottom,
          },
          index,
        ) => {
          const isConnectedtoLeft = initialLeft === initialSelectionRect.left;
          const isConnectedToRight =
            initialRight === initialSelectionRect.right;

          let left = initialLeft;
          let right = initialRight;
          let top = initialTop;
          let bottom = initialBottom;

          if (resizeDirectionRef.current === 'NW') {
            left = initialLeft + deltaClientX;
            top = initialTop + deltaClientY;
            right = initialRight;
            bottom = initialBottom;
          } else if (resizeDirectionRef.current === 'NE') {
            left = initialLeft;
            top = initialTop + deltaClientY;
            right = initialRight - deltaClientX;
            bottom = initialBottom;
          } else if (resizeDirectionRef.current === 'SE') {
            left = initialLeft;
            top = initialTop;
            right = initialRight - deltaClientX;
            bottom = initialBottom - deltaClientY;
          } else if (resizeDirectionRef.current === 'SW') {
            left = initialLeft + deltaClientX;
            top = initialTop;
            right = initialRight;
            bottom = initialBottom - deltaClientY;
          } else if (resizeDirectionRef.current === 'N') {
            left = initialLeft;
            top = initialTop + deltaClientY;
            right = initialRight;
            bottom = initialBottom;
          } else if (resizeDirectionRef.current === 'E') {
            const {
              left: selectionLeft,
              right: selectionRight,
              top: selectionTop,
              bottom: selectionBottom,
            } = initialSelectionRect;

            const deltaLeft = Math.abs(selectionLeft - initialLeft);
            const deltaRight = Math.abs(selectionRight - initialRight);
            const deltaTop = Math.abs(selectionTop - initialTop);
            const deltaBottom = Math.abs(selectionBottom - initialBottom);

            const initialSelectionWidth =
              canvasWidth - (selectionLeft + selectionRight);
            const selectionWidth = initialSelectionWidth + deltaClientX;
            const ratioX = selectionWidth / initialSelectionWidth;

            // if (index === 0) {
            //   console.log(
            //     deltaLeft,
            //     deltaRight,
            //     deltaLeft * ratioX,
            //     deltaRight * ratioX,
            //     ratioX,
            //   );
            // }

            left = isConnectedtoLeft
              ? initialLeft
              : selectionLeft + deltaLeft * ratioX;
            right = isConnectedToRight
              ? initialRight - deltaClientX
              : selectionRight + deltaRight + ratioX;

            // left = isConnectedtoLeft
            //   ? initialLeft
            //   : initialLeft - deltaLeft / 2;
            // right = isConnectedToRight
            //   ? initialRight - deltaClientX
            //   : initialRight - deltaRight / 2;

            if (index === 0) {
              console.log(canvasWidth - (left + right), ratioX);
            }

            // if (index === 1) {
            //   console.log(canvasWidth - (left + right), ratioX);
            // }

            top = initialTop;
            bottom = initialBottom;
          } else if (resizeDirectionRef.current === 'S') {
            left = initialLeft;
            top = initialTop;
            right = initialRight;
            bottom = initialBottom - deltaClientY;
          } else if (resizeDirectionRef.current === 'W') {
            left = initialLeft + deltaClientX;
            top = initialTop;
            right = initialRight;
            bottom = initialBottom;
          }
          return { id, left, right, top, bottom };
        },
      );

    // resizedElementRectList = resizedElementRectList.map(
    //   (elementRect, index) => {
    //     const selectionRect = getSelectionRect(resizedElementRectList);

    //     const initialWidth =
    //       canvasWidth -
    //       (initialSelectionRect.left + initialSelectionRect.right);
    //     const initialHeight =
    //       canvasHeight -
    //       (initialSelectionRect.top + initialSelectionRect.bottom);

    //     const width = canvasWidth - (selectionRect.left + selectionRect.right);
    //     const height =
    //       canvasHeight - (selectionRect.top + selectionRect.bottom);

    //     const percentageX = +(100 - (initialWidth * 100) / width).toFixed(2);
    //     const percentageY = +(100 - (initialHeight * 100) / height).toFixed(2);

    //     const left =
    //       initialElementRectListRef.current![index].left ===
    //       initialSelectionRect.left
    //         ? elementRect.left
    //         : initialElementRectListRef.current![index].left -
    //           ((selectionRect.left -
    //             initialElementRectListRef.current![index].left) *
    //             percentageX) /
    //             100;
    //     const top =
    //       initialElementRectListRef.current![index].top ===
    //       initialSelectionRect.top
    //         ? elementRect.top
    //         : initialElementRectListRef.current![index].top -
    //           ((selectionRect.top -
    //             initialElementRectListRef.current![index].top) *
    //             percentageY) /
    //             100;
    //     const right =
    //       initialElementRectListRef.current![index].right ===
    //       initialSelectionRect.right
    //         ? elementRect.right
    //         : initialElementRectListRef.current![index].right +
    //           ((selectionRect.right -
    //             initialElementRectListRef.current![index].right) *
    //             percentageX) /
    //             100;
    //     const bottom =
    //       initialElementRectListRef.current![index].bottom ===
    //       initialSelectionRect.bottom
    //         ? elementRect.bottom
    //         : initialElementRectListRef.current![index].bottom +
    //           ((selectionRect.bottom -
    //             initialElementRectListRef.current![index].bottom) *
    //             percentageY) /
    //             100;
    //     return {
    //       id: elementRect.id,
    //       left,
    //       right,
    //       top,
    //       bottom,
    //     };
    //   },
    // );

    (currentTarget as HTMLBodyElement).style.cursor =
      `url('/cursor/${resizeDirectionRef.current!.toLowerCase()}-resize.svg') 0 0, ${resizeDirectionRef.current!.toLowerCase()}-resize`;

    // const MINIMUM_SIZE = 10;
    // // Prevent element from getting smaller than a certain size
    // if (width <= MINIMUM_SIZE) {
    //   if (initialLeft === left) {
    //     right = canvasWidth - left - 10;
    //   } else {
    //     left = canvasWidth - right - 10;
    //   }
    // }

    // if (height <= MINIMUM_SIZE) {
    //   if (initialTop === top) {
    //     bottom = canvasWidth - top - 10;
    //   } else {
    //     top = canvasWidth - bottom - 10;
    //   }
    // }

    const resizedElementList = resizedElementRectList.map((elementRect) => {
      const element = getElementById(elementRect.id)!;
      return {
        ...element,
        position: {
          mode: element.position.mode,
          left: elementRect.left,
          right: elementRect.right,
          top: elementRect.top,
          bottom: elementRect.bottom,
        },
      };
    });

    updateElement(...resizedElementList);

    if (isSelectionVisible) {
      setSelectionVisible(false);
    }
  };

  const handleResizeEnd = (e: MouseEvent) => {
    (e.currentTarget as HTMLBodyElement).style.cursor =
      `url('/cursor/default.svg') 0 0, default`;
    setResizing(false);
    if (isSelectionVisible) {
      setSelectionVisible(true);
    }
    document.body.removeEventListener('mousemove', handleResizing);
    document.body.removeEventListener('mouseup', handleResizeEnd);
    document.body.removeEventListener('mouseleave', handleResizeEnd);
  };

  const handleResize = (
    initialMousePosition: Position,
    resizeDirection: Direction,
  ) => {
    if (elementList.every((element) => element.position.mode === 'ABSOLUTE')) {
      initialMousePositionRef.current = initialMousePosition;
      initialElementRectListRef.current = elementList.map((element) => ({
        id: element.id,
        left: element.position.mode === 'ABSOLUTE' ? +element.position.left : 0,
        right:
          element.position.mode === 'ABSOLUTE' ? +element.position.right : 0,
        top: element.position.mode === 'ABSOLUTE' ? +element.position.top : 0,
        bottom:
          element.position.mode === 'ABSOLUTE' ? +element.position.bottom : 0,
      }));
      resizeDirectionRef.current = resizeDirection;

      document.body.addEventListener('mousemove', handleResizing);
      document.body.addEventListener('mouseup', handleResizeEnd);
      document.body.addEventListener('mouseleave', handleResizeEnd);
    }
  };
  return handleResize;
}

function getSelectionRect(elementRectList: AbsoluteRect[]) {
  const left = elementRectList.reduce(
    (min, rect) => (rect.left < min ? rect.left : min),
    Number.MAX_SAFE_INTEGER,
  );

  const right = elementRectList.reduce(
    (min, rect) => (rect.right < min ? rect.right : min),
    Number.MAX_SAFE_INTEGER,
  );

  const top = elementRectList.reduce(
    (min, rect) => (rect.top < min ? rect.top : min),
    Number.MAX_SAFE_INTEGER,
  );

  const bottom = elementRectList.reduce(
    (min, rect) => (rect.bottom < min ? rect.bottom : min),
    Number.MAX_SAFE_INTEGER,
  );
  return {
    left,
    right,
    top,
    bottom,
  };
}
